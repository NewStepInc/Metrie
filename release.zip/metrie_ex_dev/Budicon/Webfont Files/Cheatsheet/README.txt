Open demo.html to show the cheatsheet
There is a icon-code and icon-name , you can copy and paste this anytime you need when you develope a website use iconfont from Budicon