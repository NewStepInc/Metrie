jQuery(function(){
	//add jQuery code here. Please use jQuery instead of the abbreviated $
});